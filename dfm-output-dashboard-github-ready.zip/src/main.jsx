import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const SHEET_ID = '1dxNnhgPRjO1Fw53ClaHxXeE64Xm4Im1xARuCx7JNzDU';
const SHEETS = {
  output: 'ALL_DATA.outputOEE',
  sapOrder: 'Order.outputSAP',
  order: 'ORDER',
};
const REFRESH_MS = 60 * 1000;

const SAMPLE_OUTPUT = [
  { date: '2026-07-01', line: 'Top1', menu: 'ข้าวเหนียวหมูทอด', output: 18420, status: '🟢 Good', insight: 'Output ดีขึ้นต่อเนื่อง ควรรักษาระดับการผลิต' },
  { date: '2026-07-01', line: 'Top2', menu: 'ผัดซีอิ๊วหมู', output: 15330, status: '🟡 Watch', insight: 'Output ต่ำกว่าเป้าหมายเล็กน้อย ควรติดตามช่วงบ่าย' },
  { date: '2026-07-01', line: 'Oni', menu: 'โอนิกิริแซลมอนย่างซีอิ๊ว', output: 22180, status: '🟢 Good', insight: 'เมนูหลักทำได้ดี' },
  { date: '2026-07-02', line: 'Top1', menu: 'ข้าวเหนียวหมูทอด', output: 19120, status: '🟢 Good', insight: 'Output เพิ่มขึ้นเทียบเมื่อวาน' },
  { date: '2026-07-02', line: 'Top2', menu: 'พะแนงหมูไข่เจียวหมูสับ', output: 13290, status: '🔴 Low', insight: 'ควรเร่งดู Capacity และวัตถุดิบ' },
  { date: '2026-07-02', line: 'Oni', menu: 'โอนิกิริแซลมอนย่างซีอิ๊ว', output: 23810, status: '🟢 Good', insight: 'Output สูงกว่าค่าเฉลี่ย' },
  { date: '2026-07-03', line: 'FFS1', menu: 'ข้าวกะเพราไก่', output: 27400, status: '🟢 Good', insight: 'ไลน์ FFS1 เป็นกำลังหลักวันนี้' },
  { date: '2026-07-03', line: 'FFS2', menu: 'ข้าวแกงไตปลาไข่เจียว', output: 9800, status: '🟡 Watch', insight: 'ต้องติดตามช่วง Night shift' },
];
const SAMPLE_ORDER = [
  { date: '2026-07-01', order: 241943 },
  { date: '2026-07-02', order: 245723 },
  { date: '2026-07-03', order: 236500 },
];

function sheetCsvUrl(sheetName) {
  return `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}&t=${Date.now()}`;
}

function parseCSV(text) {
  const rows = [];
  let row = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const n = text[i + 1];
    if (c === '"' && inQuotes && n === '"') { cur += '"'; i++; continue; }
    if (c === '"') { inQuotes = !inQuotes; continue; }
    if (c === ',' && !inQuotes) { row.push(cur); cur = ''; continue; }
    if ((c === '\n' || c === '\r') && !inQuotes) {
      if (c === '\r' && n === '\n') i++;
      row.push(cur); cur = '';
      if (row.some(v => String(v).trim() !== '')) rows.push(row);
      row = [];
      continue;
    }
    cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  const headers = (rows.shift() || []).map(h => String(h || '').trim());
  return rows.map(r => Object.fromEntries(headers.map((h, i) => [h, r[i] ?? ''])));
}

function cleanNumber(v) {
  if (v === null || v === undefined || v === '') return 0;
  const n = Number(String(v).replace(/,/g, '').replace(/[^
