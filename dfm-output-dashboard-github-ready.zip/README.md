# DFM Intelligence - Output Dashboard

เว็บ Dashboard สำหรับอ่านข้อมูลจาก Google Sheet แบบ Live โดยใช้ 3 ชีทสุดท้าย:

1. `ALL_DATA.outputOEE`
2. `Order.outputSAP`
3. `ORDER`

## วิธีอัปโหลดขึ้น GitHub

1. แตกไฟล์ ZIP นี้
2. เข้า GitHub repo `DFM-Intelligence`
3. กด `Add file` → `Upload files`
4. ลากไฟล์ทั้งหมดในโฟลเดอร์นี้เข้าไป ได้แก่ `index.html`, `package.json`, `README.md`, โฟลเดอร์ `src`
5. กด `Commit changes`

## วิธี Deploy บน Vercel

1. เข้า Vercel
2. Import repo `DFM-Intelligence`
3. ตั้งค่า:
   - Framework Preset: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
4. กด Deploy

## เงื่อนไข Google Sheet

Google Sheet ต้องตั้งค่า Share เป็น:

`Anyone with the link` → `Viewer`

เว็บจะดึงข้อมูลใหม่ทุก 60 วินาที และมีปุ่ม Refresh Live Data สำหรับดึงข้อมูลทันที

## แก้ลิงก์ Google Sheet

ถ้าต้องเปลี่ยน Sheet ID ให้แก้ในไฟล์:

`src/main.jsx`

ตรงตัวแปร:

`SHEET_ID`
